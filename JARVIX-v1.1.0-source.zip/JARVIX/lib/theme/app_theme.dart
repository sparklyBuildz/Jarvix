import 'package:flutter/material.dart';

/// JARVIX design system: OLED black surfaces, sharp crimson accents, and clear contrast.
class AppTheme {
  AppTheme._();

  // Red / black palette
  static const inkBlack = Color(0xFF050507);
  static const panelBlack = Color(0xFF100D11);
  static const panelRaised = Color(0xFF1A1218);
  static const lineRed = Color(0xFF4B1A27);
  static const accentRed = Color(0xFFFF2D55);
  static const accentBright = Color(0xFFFF647A);
  static const accentDeep = Color(0xFFB20D2D);

  static const success = Color(0xFF47D18C);
  static const danger = Color(0xFFFF365B);
  static const warning = Color(0xFFFF6A55);

  static ThemeData dark() {
    final scheme = ColorScheme.fromSeed(
      seedColor: accentRed,
      brightness: Brightness.dark,
      surface: panelBlack,
    ).copyWith(
      primary: accentBright,
      onPrimary: Colors.white,
      secondary: accentRed,
      onSecondary: Colors.white,
      tertiary: accentDeep,
      onTertiary: Colors.white,
      surface: panelBlack,
      surfaceContainerLowest: inkBlack,
      surfaceContainerLow: const Color(0xFF0D0A0E),
      surfaceContainer: const Color(0xFF140F14),
      surfaceContainerHigh: const Color(0xFF191218),
      surfaceContainerHighest: panelRaised,
      onSurface: const Color(0xFFF6F0F2),
      onSurfaceVariant: const Color(0xFFC3AEB5),
      outline: lineRed,
    );
    return _base(scheme).copyWith(
      scaffoldBackgroundColor: inkBlack,
      cardColor: panelBlack,
    );
  }

  static ThemeData light() {
    const paper = Color(0xFFFFF8FA);
    final scheme = ColorScheme.fromSeed(
      seedColor: accentDeep,
      brightness: Brightness.light,
      surface: paper,
    ).copyWith(
      primary: accentDeep,
      onPrimary: Colors.white,
      secondary: accentRed,
      surface: paper,
      surfaceContainerHighest: Colors.white,
      onSurface: const Color(0xFF201117),
      onSurfaceVariant: const Color(0xFF735E66),
      outline: const Color(0xFFE6C7D0),
    );
    return _base(scheme).copyWith(
      scaffoldBackgroundColor: paper,
      cardColor: Colors.white,
    );
  }

  static ThemeData _base(ColorScheme scheme) {
    return ThemeData(
      useMaterial3: true,
      colorScheme: scheme,
      appBarTheme: AppBarTheme(
        centerTitle: false,
        elevation: 0,
        backgroundColor: Colors.transparent,
        foregroundColor: scheme.onSurface,
        titleTextStyle: TextStyle(
          color: scheme.onSurface,
          fontSize: 20,
          fontWeight: FontWeight.w800,
          letterSpacing: 0.2,
        ),
      ),
      cardTheme: CardThemeData(
        elevation: 0,
        margin: EdgeInsets.zero,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
          side: BorderSide(color: scheme.outline.withValues(alpha: 0.55)),
        ),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: scheme.surfaceContainerHighest,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide.none,
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide(color: scheme.outline.withValues(alpha: 0.65)),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide(color: scheme.primary, width: 1.7),
        ),
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      ),
      filledButtonTheme: FilledButtonThemeData(
        style: FilledButton.styleFrom(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
        ),
      ),
      chipTheme: ChipThemeData(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        side: BorderSide(color: scheme.outline.withValues(alpha: 0.65)),
      ),
      snackBarTheme: SnackBarThemeData(
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      ),
      dividerTheme: DividerThemeData(
        color: scheme.outline.withValues(alpha: 0.5),
        thickness: 1,
      ),
    );
  }
}
