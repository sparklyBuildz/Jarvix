# Build JARVIX v1.1.0 as an Android APK

This source archive is a Flutter project. It does not contain a prebuilt APK. Build it on a computer with Flutter and the Android toolchain, or use a cloud Flutter builder such as Codemagic.

## Option 1: Build locally (recommended)

Install:

- A current Flutter stable SDK that provides **Dart 3.12.2 or newer**.
- Android Studio with the Android SDK and command-line tools.
- Java/JDK 17.

Then unzip the source archive, open a terminal in the `JARVIX` folder, and run:

```sh
flutter doctor
flutter pub get
flutter build apk --release
```

The APK will be created at:

```text
build/app/outputs/flutter-apk/app-release.apk
```

For a debug build instead, run `flutter build apk --debug`; its output is `build/app/outputs/flutter-apk/app-debug.apk`.

The default release build produces a single APK suitable for sideloading. Flutter's official Android build guide also documents split-per-CPU APKs and app bundles: <https://docs.flutter.dev/deployment/android>.

## Option 2: Build in the cloud

Codemagic can build Flutter projects for Android and let you download the APK artifact. Create a **private** Git repository with the extracted project, connect it to Codemagic, select Android, choose an APK build format and a compatible Flutter stable version, then start a Release build. See <https://docs.codemagic.io/flutter-configuration/flutter-projects/>.

## Signing and installing notes

- This project keeps the upstream package/application ID: `com.privateagent.private_agent`.
- The current Gradle release configuration signs with the **debug keystore**. That is acceptable for private testing, but do not use it for a public Play Store release. Configure and protect your own release keystore before publishing.
- Android only permits an in-place app update when the package ID **and signing certificate** match. If installing this build over an existing upstream-signed app is rejected, back up anything important, then uninstall the old app before installing the new APK; uninstalling removes that app's local data.
- JARVIX targets Android 8.0 (API 26) and later. Features such as screen automation, microphone access, and overlays require their respective Android permissions to be enabled after installation.
