import 'package:flutter/material.dart';

/// JARVIX HUD design system: deep navy surfaces, electric blue, and cyan light.
class AppTheme {
  AppTheme._();

  static const inkBlack = Color(0xFF010308);
  static const panelBlack = Color(0xFF061326);
  static const panelRaised = Color(0xFF0A1B33);
  static const lineBlue = Color(0xFF173B63);
  static const accentCyan = Color(0xFF5EE1FF);
  static const accentIce = Color(0xFF7FE9FF);
  static const accentBlue = Color(0xFF3AA8FF);
  static const accentDeepBlue = Color(0xFF2D5BFF);

  /// Compatibility aliases for older UI widgets; these now resolve to the
  /// blue HUD palette rather than the retired crimson theme.
  static const accentRed = accentCyan;
  static const accentBright = accentIce;
  static const accentDeep = accentDeepBlue;

  static const success = Color(0xFF47D18C);
  static const danger = Color(0xFFFF526B);
  static const warning = Color(0xFFFFA64D);

  static ThemeData dark() {
    final scheme = ColorScheme.fromSeed(
      seedColor: accentCyan,
      brightness: Brightness.dark,
      surface: panelBlack,
    ).copyWith(
      primary: accentCyan,
      onPrimary: const Color(0xFF00111D),
      secondary: accentBlue,
      onSecondary: const Color(0xFF00111D),
      tertiary: accentDeepBlue,
      onTertiary: Colors.white,
      surface: panelBlack,
      surfaceContainerLowest: inkBlack,
      surfaceContainerLow: const Color(0xFF07101E),
      surfaceContainer: const Color(0xFF0A172A),
      surfaceContainerHigh: const Color(0xFF0E1D33),
      surfaceContainerHighest: panelRaised,
      onSurface: const Color(0xFFEAF6FF),
      onSurfaceVariant: const Color(0xFF9FC8E8),
      outline: lineBlue,
    );
    return _base(scheme).copyWith(
      scaffoldBackgroundColor: inkBlack,
      cardColor: panelBlack,
    );
  }

  static ThemeData light() {
    const paper = Color(0xFFF5F9FE);
    final scheme = ColorScheme.fromSeed(
      seedColor: const Color(0xFF1479B8),
      brightness: Brightness.light,
      surface: paper,
    ).copyWith(
      primary: const Color(0xFF126B9E),
      onPrimary: Colors.white,
      secondary: const Color(0xFF267CC3),
      onSecondary: Colors.white,
      tertiary: accentDeepBlue,
      surface: paper,
      surfaceContainerHighest: Colors.white,
      onSurface: const Color(0xFF102334),
      onSurfaceVariant: const Color(0xFF536D82),
      outline: const Color(0xFFB9D4E8),
    );
    return _base(scheme).copyWith(
      scaffoldBackgroundColor: paper,
      cardColor: Colors.white,
    );
  }

  static ThemeData _base(ColorScheme scheme) {
    return ThemeData(
      useMaterial3: true,
      colorScheme: scheme,
      appBarTheme: AppBarTheme(
        centerTitle: false,
        elevation: 0,
        backgroundColor: Colors.transparent,
        foregroundColor: scheme.onSurface,
        titleTextStyle: TextStyle(
          color: scheme.onSurface,
          fontSize: 20,
          fontWeight: FontWeight.w800,
          letterSpacing: 0.5,
        ),
      ),
      cardTheme: CardThemeData(
        elevation: 0,
        margin: EdgeInsets.zero,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(14),
          side: BorderSide(color: scheme.outline.withValues(alpha: 0.55)),
        ),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: scheme.surfaceContainerHighest,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: BorderSide.none,
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: BorderSide(color: scheme.outline.withValues(alpha: 0.65)),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: BorderSide(color: scheme.primary, width: 1.5),
        ),
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      ),
      filledButtonTheme: FilledButtonThemeData(
        style: FilledButton.styleFrom(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 13),
        ),
      ),
      chipTheme: ChipThemeData(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
        side: BorderSide(color: scheme.outline.withValues(alpha: 0.65)),
      ),
      snackBarTheme: SnackBarThemeData(
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      ),
      dividerTheme: DividerThemeData(
        color: scheme.outline.withValues(alpha: 0.5),
        thickness: 1,
      ),
    );
  }
}
