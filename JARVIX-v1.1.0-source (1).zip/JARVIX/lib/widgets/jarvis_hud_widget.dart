import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';

import '../services/air_gesture_service.dart';
import '../services/jarvis_service.dart';
import '../services/macro_recorder_service.dart';
import '../services/proactive_agent_service.dart';
import '../services/settings_service.dart';
import 'air_gestures_hud_widget.dart';
import 'brain_dump_dialog.dart';
import 'jarvix_hud_controls.dart';

/// Responsive JARVIX dashboard, recreated in Flutter from the supplied HUD
/// mockup. Telemetry shown here is sourced from live app state; the mockup's
/// sample CPU, storage, network, and security figures are deliberately omitted.
class JarvisHudWidget extends StatefulWidget {
  final TextEditingController inputController;
  final ValueChanged<String> onSubmit;
  final Future<void> Function(String query) onGoogleSearch;
  final Future<void> Function() onVoiceTap;
  final Future<void> Function(String appName) onLaunchApp;
  final bool isListening;
  final bool isBusy;

  const JarvisHudWidget({
    super.key,
    required this.inputController,
    required this.onSubmit,
    required this.onGoogleSearch,
    required this.onVoiceTap,
    required this.onLaunchApp,
    required this.isListening,
    required this.isBusy,
  });

  @override
  State<JarvisHudWidget> createState() => _JarvisHudWidgetState();
}

class _JarvisHudWidgetState extends State<JarvisHudWidget>
    with TickerProviderStateMixin {
  static const _background = Color(0xFF010308);
  static const _panel = Color(0xB3061428);
  static const _cyan = Color(0xFF5EE1FF);
  static const _ice = Color(0xFF7FE9FF);
  static const _blue = Color(0xFF3AA8FF);
  static const _deepBlue = Color(0xFF2D5BFF);
  static const _text = Color(0xFFEAF6FF);
  static const _muted = Color(0xFF8CC8FF);

  final JarvisService _jarvis = JarvisService.instance;
  final SettingsService _settings = SettingsService.instance;

  late final AnimationController _ringController;
  late final AnimationController _pulseController;
  Timer? _clockTimer;
  DateTime _now = DateTime.now();
  DateTime _lastCoreTap = DateTime.fromMillisecondsSinceEpoch(0);

  @override
  void initState() {
    super.initState();
    _ringController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 28),
    )..repeat();
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1900),
    )..repeat(reverse: true);

    _jarvis.addListener(_onServiceUpdate);
    _settings.addListener(_onServiceUpdate);
    ProactiveAgentService.instance.addListener(_onServiceUpdate);
    AirGestureService.instance.addListener(_onServiceUpdate);
    MacroRecorderService.instance.addListener(_onServiceUpdate);
    _clockTimer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted) setState(() => _now = DateTime.now());
    });
  }

  void _onServiceUpdate() {
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    _clockTimer?.cancel();
    _jarvis.removeListener(_onServiceUpdate);
    _settings.removeListener(_onServiceUpdate);
    ProactiveAgentService.instance.removeListener(_onServiceUpdate);
    AirGestureService.instance.removeListener(_onServiceUpdate);
    MacroRecorderService.instance.removeListener(_onServiceUpdate);
    _ringController.dispose();
    _pulseController.dispose();
    super.dispose();
  }

  Color _accentForPhase(JarvisPhase phase) => switch (phase) {
        JarvisPhase.thinking => _ice,
        JarvisPhase.executing => _blue,
        JarvisPhase.speaking => const Color(0xFFB4F4FF),
        JarvisPhase.listening => _cyan,
        JarvisPhase.idle => _cyan,
      };

  Future<void> _handleCoreTap() async {
    final now = DateTime.now();
    if (now.difference(_lastCoreTap).inMilliseconds < 350) return;
    _lastCoreTap = now;
    HapticFeedback.lightImpact();
    await _jarvis.toggleListening();
  }

  String get _salutation {
    if (_now.hour < 12) return 'GOOD MORNING';
    if (_now.hour < 17) return 'GOOD AFTERNOON';
    return 'GOOD EVENING';
  }

  String get _phaseLabel => switch (_jarvis.phase) {
        JarvisPhase.idle => _jarvis.isAwake ? 'READY FOR INPUT' : 'WAKE WORD ACTIVE',
        JarvisPhase.listening => 'LISTENING',
        JarvisPhase.thinking => 'ANALYZING REQUEST',
        JarvisPhase.executing => 'EXECUTING TASK',
        JarvisPhase.speaking => 'VOICE RESPONSE',
      };

  @override
  Widget build(BuildContext context) {
    final keyboardVisible = MediaQuery.viewInsetsOf(context).bottom > 0;
    final accent = _accentForPhase(_jarvis.phase);

    return Container(
      color: _background,
      child: Stack(
        fit: StackFit.expand,
        children: [
          DecoratedBox(
            decoration: const BoxDecoration(
              gradient: RadialGradient(
                center: Alignment(0, -0.12),
                radius: 1.15,
                colors: [Color(0xFF0B2A5C), Color(0xFF031026), _background],
                stops: [0, 0.46, 1],
              ),
            ),
          ),
          Positioned.fill(
            child: CustomPaint(painter: _HudGridPainter(accent: accent)),
          ),
          Positioned.fill(
            child: IgnorePointer(
              child: CustomPaint(painter: _HudCornerPainter(accent: accent)),
            ),
          ),
          SafeArea(
            top: false,
            bottom: true,
            child: LayoutBuilder(
              builder: (context, constraints) {
                final compact = constraints.maxHeight < 600;
                return Column(
                  children: [
                    _buildTopRuler(accent),
                    if (!keyboardVisible) ...[
                      const SizedBox(height: 6),
                      _buildDateAndVoiceRow(accent),
                      if (!compact) ...[
                        const SizedBox(height: 7),
                        _buildLiveReadouts(accent),
                      ],
                    ],
                    Expanded(
                      child: SingleChildScrollView(
                        physics: const BouncingScrollPhysics(),
                        padding: const EdgeInsets.fromLTRB(10, 7, 10, 8),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            _buildStatusPill(accent),
                            const SizedBox(height: 2),
                            _buildReactorStage(
                              width: constraints.maxWidth,
                              availableHeight: constraints.maxHeight,
                              compact: compact || keyboardVisible,
                              accent: accent,
                            ),
                            _buildAirGestureBanner(accent),
                            if (!keyboardVisible) ...[
                              _buildProactiveBanner(accent),
                              _buildLatestResponse(accent),
                              JarvixAppLaunchRow(onLaunchApp: widget.onLaunchApp),
                              _buildModuleDock(accent),
                            ],
                          ],
                        ),
                      ),
                    ),
                    if (!keyboardVisible)
                      Padding(
                        padding: const EdgeInsets.only(bottom: 4),
                        child: Container(
                          height: 1,
                          margin: const EdgeInsets.symmetric(horizontal: 20),
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              colors: [
                                Colors.transparent,
                                _blue.withValues(alpha: 0.8),
                                Colors.transparent,
                              ],
                            ),
                          ),
                        ),
                      ),
                    JarvixCommandDock(
                      controller: widget.inputController,
                      onAskJarvix: widget.onSubmit,
                      onGoogleSearch: widget.onGoogleSearch,
                      onVoiceTap: widget.onVoiceTap,
                      isListening: widget.isListening,
                      isBusy: widget.isBusy ||
                          _jarvis.phase == JarvisPhase.thinking ||
                          _jarvis.phase == JarvisPhase.executing,
                    ),
                    if (!keyboardVisible)
                      Padding(
                        padding: const EdgeInsets.fromLTRB(12, 4, 12, 7),
                        child: Text(
                          _jarvis.phase == JarvisPhase.listening
                              ? 'LISTENING // SAY YOUR COMMAND'
                              : 'SAY “HEY JARVIS” OR TAP THE CORE',
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            color: accent.withValues(alpha: 0.68),
                            fontSize: 9,
                            fontWeight: FontWeight.w700,
                            letterSpacing: 1.6,
                            fontFamily: 'monospace',
                          ),
                        ),
                      ),
                  ],
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTopRuler(Color accent) {
    final activeTick = _now.second % 18;
    return Padding(
      padding: const EdgeInsets.fromLTRB(14, 5, 14, 0),
      child: SizedBox(
        height: 24,
        child: Row(
          children: [
            const Text(
              'JARVIX',
              style: TextStyle(
                color: _text,
                fontSize: 12,
                fontWeight: FontWeight.w900,
                letterSpacing: 3,
                fontFamily: 'monospace',
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Row(
                children: List.generate(18, (index) {
                  final lit = index == activeTick || index == activeTick - 1;
                  return Expanded(
                    child: Container(
                      height: index % 3 == 0 ? 17 : 11,
                      margin: const EdgeInsets.symmetric(horizontal: 1.3),
                      alignment: Alignment.center,
                      decoration: BoxDecoration(
                        color: lit
                            ? accent.withValues(alpha: 0.9)
                            : const Color(0xFF08244A),
                        border: Border.all(
                          color: accent.withValues(alpha: lit ? 0.55 : 0.22),
                          width: 0.6,
                        ),
                        boxShadow: lit
                            ? [
                                BoxShadow(
                                  color: accent.withValues(alpha: 0.4),
                                  blurRadius: 7,
                                ),
                              ]
                            : null,
                      ),
                    ),
                  );
                }),
              ),
            ),
            const SizedBox(width: 10),
            _LinkIndicator(active: widget.isListening || _jarvis.phase == JarvisPhase.speaking),
          ],
        ),
      ),
    );
  }

  Widget _buildDateAndVoiceRow(Color accent) {
    final datePanel = _HudPanel(
      accent: accent,
      padding: const EdgeInsets.fromLTRB(12, 8, 10, 7),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            DateFormat('EEEE').format(_now).toUpperCase(),
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(
              color: _muted,
              fontSize: 9,
              fontWeight: FontWeight.w700,
              letterSpacing: 2,
            ),
          ),
          const SizedBox(height: 1),
          Row(
            crossAxisAlignment: CrossAxisAlignment.baseline,
            textBaseline: TextBaseline.alphabetic,
            children: [
              Text(
                DateFormat('dd').format(_now),
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 27,
                  height: 1,
                  fontWeight: FontWeight.w900,
                  fontFamily: 'monospace',
                  shadows: [Shadow(color: _blue, blurRadius: 14)],
                ),
              ),
              const SizedBox(width: 8),
              Flexible(
                child: Text(
                  DateFormat('MMM yyyy').format(_now).toUpperCase(),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: _text,
                    fontSize: 12,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 1.5,
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );

    final voiceActive = widget.isListening || _jarvis.phase == JarvisPhase.speaking;
    final voicePanel = _HudPanel(
      accent: accent,
      padding: const EdgeInsets.fromLTRB(12, 8, 10, 7),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'VOICE CHANNEL',
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
              color: _muted,
              fontSize: 9,
              fontWeight: FontWeight.w700,
              letterSpacing: 1.6,
            ),
          ),
          const SizedBox(height: 6),
          Row(
            children: [
              _GlowingDot(color: voiceActive ? accent : _muted.withValues(alpha: 0.5)),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  voiceActive ? 'ACTIVE' : 'STANDBY',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    color: voiceActive ? Colors.white : _muted,
                    fontSize: 15,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 1.3,
                    fontFamily: 'monospace',
                    shadows: voiceActive
                        ? [Shadow(color: accent.withValues(alpha: 0.8), blurRadius: 10)]
                        : null,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 2),
          Text(
            _settings.jarvisAlwaysOn ? 'ALWAYS-ON ENABLED' : 'JARVIX MODE',
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(
              color: _muted,
              fontSize: 8,
              fontWeight: FontWeight.w600,
              letterSpacing: 1.1,
            ),
          ),
        ],
      ),
    );

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: Row(
        children: [
          Expanded(child: datePanel),
          const SizedBox(width: 8),
          Expanded(child: voicePanel),
        ],
      ),
    );
  }

  Widget _buildLiveReadouts(Color accent) {
    final voiceValue = _jarvis.phase == JarvisPhase.listening
        ? 'LIVE'
        : (_settings.jarvisAlwaysOn ? 'ARMED' : 'READY');
    final sessionValue = _jarvis.isInJarvisMode ? 'ACTIVE' : 'STANDBY';
    final taskValue = _jarvis.phase == JarvisPhase.executing
        ? 'RUNNING'
        : 'READY';

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: Row(
        children: [
          Expanded(child: _ReadoutCard(label: 'VOICE', value: voiceValue, accent: accent)),
          const SizedBox(width: 7),
          Expanded(child: _ReadoutCard(label: 'SESSION', value: sessionValue, accent: accent)),
          const SizedBox(width: 7),
          Expanded(child: _ReadoutCard(label: 'AUTOMATION', value: taskValue, accent: accent)),
        ],
      ),
    );
  }

  Widget _buildStatusPill(Color accent) {
    final (label, icon) = switch (_jarvis.phase) {
      JarvisPhase.idle => (
          _jarvis.isAwake ? 'READY // LISTENING WINDOW OPEN' : 'STANDBY // SAY “HEY JARVIS”',
          Icons.radar_rounded,
        ),
      JarvisPhase.listening => ('LISTENING // AUDIO RECEPTORS ACTIVE', Icons.graphic_eq_rounded),
      JarvisPhase.thinking => ('COMPUTING // ANALYZING REQUEST', Icons.psychology_alt_rounded),
      JarvisPhase.executing => (
          _jarvis.currentStep > 0 ? 'AUTOMATION // STEP ${_jarvis.currentStep}' : 'TASK IN PROGRESS',
          Icons.bolt_rounded,
        ),
      JarvisPhase.speaking => ('SPEAKING // AUDIO RESPONSE', Icons.volume_up_rounded),
    };

    return Padding(
      padding: const EdgeInsets.fromLTRB(8, 0, 8, 2),
      child: Container(
        constraints: const BoxConstraints(maxWidth: 460),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
        decoration: BoxDecoration(
          color: _panel,
          borderRadius: BorderRadius.circular(6),
          border: Border.all(color: accent.withValues(alpha: 0.52), width: 0.9),
          boxShadow: [
            BoxShadow(
              color: accent.withValues(alpha: 0.10),
              blurRadius: 16,
              spreadRadius: 1,
            ),
          ],
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, size: 14, color: accent),
            const SizedBox(width: 8),
            Flexible(
              child: Text(
                label,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  color: _text,
                  fontSize: 9,
                  fontWeight: FontWeight.w800,
                  letterSpacing: 1.1,
                  fontFamily: 'monospace',
                ),
              ),
            ),
            if (_jarvis.phase == JarvisPhase.executing) ...[
              const SizedBox(width: 10),
              IconButton(
                tooltip: 'Stop current task',
                visualDensity: VisualDensity.compact,
                constraints: const BoxConstraints(minWidth: 26, minHeight: 26),
                padding: EdgeInsets.zero,
                onPressed: _jarvis.abortTask,
                icon: const Icon(Icons.stop_circle_outlined, size: 18, color: Color(0xFFFF6176)),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildReactorStage({
    required double width,
    required double availableHeight,
    required bool compact,
    required Color accent,
  }) {
    final maxDiameter = math.min(width * 0.78, compact ? 224.0 : 284.0);
    final heightLimit = math.max(174.0, availableHeight * (compact ? 0.34 : 0.40));
    final diameter = math.min(maxDiameter, heightLimit).clamp(174.0, 284.0).toDouble();
    final isHologram = _settings.jarvisScreenStyle == JarvisScreenStyle.jarvis;

    return SizedBox(
      height: diameter + 14,
      child: Center(
        child: GestureDetector(
          behavior: HitTestBehavior.opaque,
          onTap: _handleCoreTap,
          child: SizedBox.square(
            dimension: diameter,
            child: AnimatedBuilder(
              animation: Listenable.merge([_ringController, _pulseController]),
              builder: (context, _) {
                return CustomPaint(
                  painter: _HudReactorPainter(
                    rotation: _ringController.value,
                    pulse: _pulseController.value,
                    accent: accent,
                    isHologram: isHologram,
                    isSpeaking: _jarvis.phase == JarvisPhase.speaking,
                  ),
                  child: Center(
                    child: Padding(
                      padding: const EdgeInsets.all(28),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text(
                            _salutation,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                              color: _muted,
                              fontSize: 8,
                              fontWeight: FontWeight.w700,
                              letterSpacing: 2.1,
                            ),
                          ),
                          const SizedBox(height: 2),
                          Text(
                            DateFormat('HH:mm').format(_now),
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 38,
                              height: 1.1,
                              fontWeight: FontWeight.w900,
                              letterSpacing: 1,
                              fontFamily: 'monospace',
                              shadows: [
                                Shadow(color: Color(0xFF3AA8FF), blurRadius: 20),
                              ],
                            ),
                          ),
                          const SizedBox(height: 2),
                          Text(
                            _phaseLabel,
                            textAlign: TextAlign.center,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                              color: accent,
                              fontSize: 8,
                              fontWeight: FontWeight.w900,
                              letterSpacing: 1.4,
                              fontFamily: 'monospace',
                            ),
                          ),
                          const SizedBox(height: 5),
                          Text(
                            _jarvis.phase == JarvisPhase.idle && !_jarvis.isAwake
                                ? (_settings.jarvisAlwaysOn ? 'SAY “HEY JARVIS”' : 'TAP TO SPEAK')
                                : 'TAP TO TALK',
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                              color: _text,
                              fontSize: 8,
                              fontWeight: FontWeight.w600,
                              letterSpacing: 1.2,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildAirGestureBanner(Color accent) {
    return ValueListenableBuilder<String?>(
      valueListenable: AirGestureService.instance.activeGestureBanner,
      builder: (context, banner, _) {
        if (banner == null) return const SizedBox.shrink();
        return Padding(
          padding: const EdgeInsets.fromLTRB(14, 0, 14, 7),
          child: _HudPanel(
            accent: accent,
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            child: Row(
              children: [
                Icon(Icons.pan_tool_outlined, size: 16, color: accent),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    banner,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      color: _text,
                      fontSize: 11,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildProactiveBanner(Color accent) {
    final suggestion = ProactiveAgentService.instance.currentSuggestion;
    if (suggestion == null) return const SizedBox.shrink();

    return Padding(
      padding: const EdgeInsets.fromLTRB(14, 3, 14, 7),
      child: _HudPanel(
        accent: accent,
        padding: const EdgeInsets.all(10),
        child: Row(
          children: [
            Icon(Icons.auto_awesome, color: accent, size: 18),
            const SizedBox(width: 9),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    suggestion.title.toUpperCase(),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      color: accent,
                      fontSize: 9,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 1.1,
                      fontFamily: 'monospace',
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    suggestion.description,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(color: _text, fontSize: 11, height: 1.2),
                  ),
                ],
              ),
            ),
            const SizedBox(width: 8),
            _HudActionButton(
              label: 'RUN',
              accent: accent,
              onPressed: () {
                final goal = suggestion.actionGoal;
                ProactiveAgentService.instance.dismissSuggestion();
                _jarvis.processCommand(goal);
              },
            ),
            IconButton(
              tooltip: 'Dismiss suggestion',
              visualDensity: VisualDensity.compact,
              constraints: const BoxConstraints(minWidth: 28, minHeight: 28),
              padding: EdgeInsets.zero,
              onPressed: ProactiveAgentService.instance.dismissSuggestion,
              icon: Icon(Icons.close, color: _muted.withValues(alpha: 0.8), size: 16),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildLatestResponse(Color accent) {
    final response = _jarvis.lastJarvisSpeech.trim();
    const initialResponse = 'At your service, sir. Say "Hey JARVIX" anytime.';
    if (response.isEmpty || response == initialResponse) return const SizedBox.shrink();

    return Padding(
      padding: const EdgeInsets.fromLTRB(14, 1, 14, 7),
      child: _HudPanel(
        accent: accent,
        padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 8),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(Icons.graphic_eq_rounded, color: accent, size: 17),
            const SizedBox(width: 9),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    'JARVIX RESPONSE',
                    style: TextStyle(
                      color: accent,
                      fontSize: 8,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 1.6,
                      fontFamily: 'monospace',
                    ),
                  ),
                  const SizedBox(height: 3),
                  Text(
                    response,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(color: _text, fontSize: 11, height: 1.25),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildModuleDock(Color accent) {
    final settings = _settings;
    final airGestures = AirGestureService.instance;
    final macros = MacroRecorderService.instance;

    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 3, 12, 5),
      child: Column(
        children: [
          Row(
            children: [
              Text(
                'SYSTEM MODULES',
                style: TextStyle(
                  color: accent.withValues(alpha: 0.92),
                  fontSize: 8,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 1.6,
                  fontFamily: 'monospace',
                ),
              ),
              const SizedBox(width: 8),
              Expanded(child: Container(height: 1, color: accent.withValues(alpha: 0.22))),
            ],
          ),
          const SizedBox(height: 7),
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            physics: const BouncingScrollPhysics(),
            child: Row(
              children: [
                ListenableBuilder(
                  listenable: settings,
                  builder: (context, _) {
                    final enabled = settings.jarvisAlwaysOn;
                    return _HudModuleChip(
                      icon: enabled ? Icons.hearing_rounded : Icons.hearing_disabled_rounded,
                      label: enabled ? 'ALWAYS-ON' : 'WAKE LISTENER',
                      active: enabled,
                      accent: accent,
                      onTap: () async {
                        final next = !settings.jarvisAlwaysOn;
                        await settings.setJarvisAlwaysOn(next);
                        if (next) {
                          _jarvis.ensureAlwaysOnRunning();
                        } else {
                          _jarvis.stopAlwaysOn();
                        }
                      },
                    );
                  },
                ),
                const SizedBox(width: 7),
                _HudModuleChip(
                  icon: Icons.alt_route_rounded,
                  label: 'MULTITASK',
                  accent: accent,
                  onTap: () {
                    HapticFeedback.selectionClick();
                    showDialog<void>(
                      context: context,
                      barrierColor: Colors.black.withValues(alpha: 0.72),
                      builder: (_) => const BrainDumpDialog(),
                    );
                  },
                ),
                const SizedBox(width: 7),
                _HudModuleChip(
                  icon: Icons.psychology_alt_rounded,
                  label: 'SELF EVOLVE',
                  accent: accent,
                  onTap: () => _jarvis.processCommand('self evolve'),
                ),
                const SizedBox(width: 7),
                ListenableBuilder(
                  listenable: airGestures,
                  builder: (context, _) => _HudModuleChip(
                    icon: airGestures.isEnabled
                        ? Icons.pan_tool_rounded
                        : Icons.pan_tool_outlined,
                    label: 'AIR GESTURES',
                    accent: accent,
                    active: airGestures.isEnabled,
                    onTap: () {
                      HapticFeedback.selectionClick();
                      showDialog<void>(
                        context: context,
                        barrierColor: Colors.black.withValues(alpha: 0.72),
                        builder: (_) => const AirGesturesHudWidget(),
                      );
                    },
                    onLongPress: () {
                      HapticFeedback.mediumImpact();
                      unawaited(airGestures.toggleAirGestures().then<void>((_) {}));
                    },
                  ),
                ),
                const SizedBox(width: 7),
                ListenableBuilder(
                  listenable: settings,
                  builder: (context, _) {
                    final isArc = settings.jarvisScreenStyle == JarvisScreenStyle.arcReactor;
                    return _HudModuleChip(
                      icon: isArc ? Icons.blur_circular_rounded : Icons.hexagon_outlined,
                      label: isArc ? 'REACTOR' : 'HOLOGRAM',
                      accent: accent,
                      active: true,
                      onTap: () => settings.setJarvisScreenStyle(
                        isArc ? JarvisScreenStyle.jarvis : JarvisScreenStyle.arcReactor,
                      ),
                    );
                  },
                ),
                const SizedBox(width: 7),
                ListenableBuilder(
                  listenable: macros,
                  builder: (context, _) {
                    final recording = macros.isRecording;
                    return _HudModuleChip(
                      icon: recording ? Icons.stop_rounded : Icons.fiber_manual_record_rounded,
                      label: recording ? 'SAVE MACRO' : 'MACRO REC',
                      accent: recording ? const Color(0xFFFF6176) : accent,
                      active: recording,
                      onTap: () => _jarvis.processCommand(
                        recording ? 'save macro' : 'record macro Custom Task',
                      ),
                    );
                  },
                ),
              ],
            ),
          ),
          const SizedBox(height: 5),
          Text(
            'AIR GESTURES: TAP FOR CONTROLS · HOLD TO TOGGLE',
            style: TextStyle(
              color: _muted.withValues(alpha: 0.55),
              fontSize: 7,
              letterSpacing: 1,
              fontFamily: 'monospace',
            ),
          ),
        ],
      ),
    );
  }
}

class _HudPanel extends StatelessWidget {
  final Widget child;
  final Color accent;
  final EdgeInsetsGeometry padding;

  const _HudPanel({
    required this.child,
    required this.accent,
    this.padding = const EdgeInsets.all(10),
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: padding,
      decoration: BoxDecoration(
        color: _JarvisHudWidgetState._panel,
        borderRadius: const BorderRadius.only(
          topLeft: Radius.circular(5),
          topRight: Radius.circular(15),
          bottomLeft: Radius.circular(15),
          bottomRight: Radius.circular(5),
        ),
        border: Border.all(color: accent.withValues(alpha: 0.32), width: 0.8),
        boxShadow: [
          BoxShadow(color: accent.withValues(alpha: 0.06), blurRadius: 14),
        ],
      ),
      child: child,
    );
  }
}

class _GlowingDot extends StatelessWidget {
  final Color color;
  const _GlowingDot({required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 7,
      height: 7,
      decoration: BoxDecoration(
        color: color,
        shape: BoxShape.circle,
        boxShadow: [BoxShadow(color: color.withValues(alpha: 0.8), blurRadius: 8)],
      ),
    );
  }
}

class _LinkIndicator extends StatelessWidget {
  final bool active;
  const _LinkIndicator({required this.active});

  @override
  Widget build(BuildContext context) {
    final color = active ? _JarvisHudWidgetState._cyan : _JarvisHudWidgetState._muted;
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        _GlowingDot(color: color),
        const SizedBox(width: 5),
        Text(
          active ? 'LINK' : 'IDLE',
          style: TextStyle(
            color: color,
            fontSize: 8,
            fontWeight: FontWeight.w900,
            letterSpacing: 1,
            fontFamily: 'monospace',
          ),
        ),
      ],
    );
  }
}

class _ReadoutCard extends StatelessWidget {
  final String label;
  final String value;
  final Color accent;

  const _ReadoutCard({required this.label, required this.value, required this.accent});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(8, 6, 5, 6),
      decoration: BoxDecoration(
        color: _JarvisHudWidgetState._panel,
        border: Border.all(color: accent.withValues(alpha: 0.26), width: 0.7),
        borderRadius: BorderRadius.circular(4),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            label,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(
              color: _JarvisHudWidgetState._muted,
              fontSize: 7,
              fontWeight: FontWeight.w700,
              letterSpacing: 1.1,
            ),
          ),
          const SizedBox(height: 2),
          Text(
            value,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
              color: accent,
              fontSize: 10,
              fontWeight: FontWeight.w900,
              letterSpacing: 0.7,
              fontFamily: 'monospace',
            ),
          ),
        ],
      ),
    );
  }
}

class _HudActionButton extends StatelessWidget {
  final String label;
  final Color accent;
  final VoidCallback onPressed;

  const _HudActionButton({required this.label, required this.accent, required this.onPressed});

  @override
  Widget build(BuildContext context) {
    return TextButton(
      onPressed: onPressed,
      style: TextButton.styleFrom(
        minimumSize: const Size(44, 32),
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
        foregroundColor: accent,
        backgroundColor: accent.withValues(alpha: 0.13),
        side: BorderSide(color: accent.withValues(alpha: 0.46)),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(5)),
      ),
      child: Text(
        label,
        style: const TextStyle(fontSize: 9, fontWeight: FontWeight.w900, letterSpacing: 1),
      ),
    );
  }
}

class _HudModuleChip extends StatelessWidget {
  final IconData icon;
  final String label;
  final Color accent;
  final bool active;
  final VoidCallback onTap;
  final VoidCallback? onLongPress;

  const _HudModuleChip({
    required this.icon,
    required this.label,
    required this.accent,
    required this.onTap,
    this.active = false,
    this.onLongPress,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        onLongPress: onLongPress,
        borderRadius: BorderRadius.circular(5),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 180),
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
          decoration: BoxDecoration(
            color: accent.withValues(alpha: active ? 0.18 : 0.07),
            border: Border.all(
              color: accent.withValues(alpha: active ? 0.72 : 0.32),
              width: active ? 1 : 0.7,
            ),
            borderRadius: BorderRadius.circular(5),
            boxShadow: active
                ? [BoxShadow(color: accent.withValues(alpha: 0.13), blurRadius: 9)]
                : null,
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(icon, color: accent, size: 13),
              const SizedBox(width: 5),
              Text(
                label,
                style: TextStyle(
                  color: active ? Colors.white : _JarvisHudWidgetState._muted,
                  fontSize: 8,
                  fontWeight: FontWeight.w800,
                  letterSpacing: 0.8,
                  fontFamily: 'monospace',
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _HudGridPainter extends CustomPainter {
  final Color accent;
  const _HudGridPainter({required this.accent});

  @override
  void paint(Canvas canvas, Size size) {
    final spacing = size.width < 420 ? 32.0 : 40.0;
    final paint = Paint()
      ..color = accent.withValues(alpha: 0.055)
      ..strokeWidth = 0.5;
    for (double x = 0; x < size.width; x += spacing) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    }
    for (double y = 0; y < size.height; y += spacing) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }

    final glowPaint = Paint()
      ..shader = RadialGradient(
        colors: [
          accent.withValues(alpha: 0.09),
          accent.withValues(alpha: 0.025),
          Colors.transparent,
        ],
        stops: const [0, 0.45, 1],
      ).createShader(Rect.fromCenter(
        center: Offset(size.width * 0.5, size.height * 0.42),
        width: size.width * 1.1,
        height: size.height * 1.1,
      ));
    canvas.drawRect(Offset.zero & size, glowPaint);
  }

  @override
  bool shouldRepaint(covariant _HudGridPainter oldDelegate) => accent != oldDelegate.accent;
}

class _HudCornerPainter extends CustomPainter {
  final Color accent;
  const _HudCornerPainter({required this.accent});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = accent.withValues(alpha: 0.58)
      ..strokeWidth = 1.3
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.square;
    const inset = 7.0;
    const length = 22.0;
    final corners = <(Offset, Offset, Offset)>[
      (const Offset(inset, inset), const Offset(inset + length, inset), const Offset(inset, inset + length)),
      (Offset(size.width - inset, inset), Offset(size.width - inset - length, inset), Offset(size.width - inset, inset + length)),
      (Offset(inset, size.height - inset), Offset(inset + length, size.height - inset), Offset(inset, size.height - inset - length)),
      (Offset(size.width - inset, size.height - inset), Offset(size.width - inset - length, size.height - inset), Offset(size.width - inset, size.height - inset - length)),
    ];
    for (final corner in corners) {
      canvas.drawLine(corner.$1, corner.$2, paint);
      canvas.drawLine(corner.$1, corner.$3, paint);
    }
  }

  @override
  bool shouldRepaint(covariant _HudCornerPainter oldDelegate) => accent != oldDelegate.accent;
}

class _HudReactorPainter extends CustomPainter {
  final double rotation;
  final double pulse;
  final Color accent;
  final bool isHologram;
  final bool isSpeaking;

  const _HudReactorPainter({
    required this.rotation,
    required this.pulse,
    required this.accent,
    required this.isHologram,
    required this.isSpeaking,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final center = size.center(Offset.zero);
    final radius = math.min(size.width, size.height) * 0.48;
    final glow = Paint()
      ..shader = RadialGradient(
        colors: [
          accent.withValues(alpha: 0.28 + 0.12 * pulse),
          const Color(0xFF1765FF).withValues(alpha: 0.14),
          Colors.transparent,
        ],
        stops: const [0, 0.55, 1],
      ).createShader(Rect.fromCircle(center: center, radius: radius));
    canvas.drawCircle(center, radius, glow);

    final ringBase = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1
      ..color = accent.withValues(alpha: 0.24);
    for (var ring = 0; ring < 6; ring++) {
      final r = radius * (0.43 + ring * 0.105);
      canvas.drawCircle(center, r, ringBase..color = accent.withValues(alpha: 0.12 + ring * 0.025));
    }

    final ticks = Paint()
      ..strokeCap = StrokeCap.square
      ..color = accent.withValues(alpha: 0.58);
    for (var index = 0; index < 80; index++) {
      final angle = index / 80 * math.pi * 2;
      final major = index % 5 == 0;
      final inner = radius * (major ? 0.88 : 0.925);
      final outer = radius * (major ? 1.0 : 0.96);
      ticks
        ..strokeWidth = major ? 1.4 : 0.7
        ..color = accent.withValues(alpha: major ? 0.78 : 0.40);
      canvas.drawLine(
        Offset(center.dx + math.cos(angle) * inner, center.dy + math.sin(angle) * inner),
        Offset(center.dx + math.cos(angle) * outer, center.dy + math.sin(angle) * outer),
        ticks,
      );
    }

    final arcRect = Rect.fromCircle(center: center, radius: radius * 0.82);
    final arcPaint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round
      ..strokeWidth = 5
      ..color = accent.withValues(alpha: 0.82);
    canvas.drawArc(arcRect, rotation * math.pi * 2, math.pi * 0.72, false, arcPaint);

    final reverseArc = Paint()
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round
      ..strokeWidth = 2.2
      ..color = const Color(0xFF7FE9FF).withValues(alpha: 0.74);
    canvas.drawArc(
      Rect.fromCircle(center: center, radius: radius * 0.68),
      -rotation * math.pi * 2 + math.pi * 0.52,
      math.pi * 0.95,
      false,
      reverseArc,
    );

    final dashedRadius = radius * 0.56;
    final dashedPaint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.3
      ..strokeCap = StrokeCap.round
      ..color = accent.withValues(alpha: 0.70);
    for (var segment = 0; segment < 22; segment++) {
      final start = segment / 22 * math.pi * 2 + rotation * math.pi * 2;
      canvas.drawArc(
        Rect.fromCircle(center: center, radius: dashedRadius),
        start,
        math.pi / 54,
        false,
        dashedPaint,
      );
    }

    final coreRadius = radius * (isHologram ? 0.39 : 0.42);
    final corePaint = Paint()
      ..shader = RadialGradient(
        colors: [
          const Color(0xFF7FE9FF).withValues(alpha: 0.20 + pulse * 0.1),
          const Color(0xFF0A3F9C).withValues(alpha: 0.58),
          const Color(0xFF03132D).withValues(alpha: 0.96),
        ],
        stops: const [0, 0.55, 1],
      ).createShader(Rect.fromCircle(center: center, radius: coreRadius));
    canvas.drawCircle(center, coreRadius, corePaint);
    canvas.drawCircle(
      center,
      coreRadius,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.2
        ..color = accent.withValues(alpha: 0.74),
    );

    if (isHologram) {
      final path = Path();
      for (var point = 0; point < 6; point++) {
        final angle = point / 6 * math.pi * 2 - math.pi / 2;
        final vertex = Offset(
          center.dx + math.cos(angle) * coreRadius * 0.73,
          center.dy + math.sin(angle) * coreRadius * 0.73,
        );
        if (point == 0) {
          path.moveTo(vertex.dx, vertex.dy);
        } else {
          path.lineTo(vertex.dx, vertex.dy);
        }
      }
      path.close();
      canvas.drawPath(
        path,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 1
          ..color = accent.withValues(alpha: 0.52),
      );
    } else {
      canvas.drawCircle(
        center,
        coreRadius * 0.66,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 1
          ..color = accent.withValues(alpha: 0.4),
      );
    }

    final centerDot = Paint()
      ..color = isSpeaking ? Colors.white : accent
      ..maskFilter = MaskFilter.blur(BlurStyle.normal, 5 + pulse * 4);
    canvas.drawCircle(center, coreRadius * 0.11, centerDot);

    for (var node = 0; node < 3; node++) {
      final angle = rotation * math.pi * 2 * (node.isEven ? 1 : -1) + node * math.pi * 2 / 3;
      final nodeRadius = radius * (0.58 + (node % 2) * 0.1);
      canvas.drawCircle(
        Offset(center.dx + math.cos(angle) * nodeRadius, center.dy + math.sin(angle) * nodeRadius),
        node == 0 ? 3.1 : 2.2,
        Paint()..color = accent.withValues(alpha: 0.88),
      );
    }
  }

  @override
  bool shouldRepaint(covariant _HudReactorPainter oldDelegate) =>
      rotation != oldDelegate.rotation ||
      pulse != oldDelegate.pulse ||
      accent != oldDelegate.accent ||
      isHologram != oldDelegate.isHologram ||
      isSpeaking != oldDelegate.isSpeaking;
}
