import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

/// Cyan-on-navy quick launcher strip for the apps the user asked to reach first.
class JarvixAppLaunchRow extends StatelessWidget {
  final Future<void> Function(String appName) onLaunchApp;

  const JarvixAppLaunchRow({
    super.key,
    required this.onLaunchApp,
  });

  static const _accent = Color(0xFF5EE1FF);
  static const _apps = <({String label, String target, IconData icon})>[
    (label: 'YouTube', target: 'YouTube', icon: Icons.smart_display_rounded),
    (label: 'Spotify', target: 'Spotify', icon: Icons.music_note_rounded),
    (label: 'Google', target: 'Google', icon: Icons.travel_explore_rounded),
    (label: 'Chrome', target: 'Chrome', icon: Icons.language_rounded),
  ];

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(14, 2, 14, 5),
      child: Column(
        children: [
          ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 680),
            child: Padding(
              padding: const EdgeInsets.fromLTRB(2, 0, 2, 7),
              child: Row(
                children: [
                  Container(
                    width: 6,
                    height: 6,
                    decoration: const BoxDecoration(
                      shape: BoxShape.circle,
                      color: _accent,
                      boxShadow: [
                        BoxShadow(color: _accent, blurRadius: 8),
                      ],
                    ),
                  ),
                  const SizedBox(width: 8),
                  const Text(
                    'QUICK LAUNCH',
                    style: TextStyle(
                      color: Color(0xFFEAF6FF),
                      fontSize: 9,
                      fontWeight: FontWeight.w800,
                      letterSpacing: 1.8,
                      fontFamily: 'monospace',
                    ),
                  ),
                  const Spacer(),
                  Text(
                    'TAP TO OPEN',
                    style: TextStyle(
                      color: Colors.white.withValues(alpha: 0.36),
                      fontSize: 8,
                      letterSpacing: 1.2,
                      fontFamily: 'monospace',
                    ),
                  ),
                ],
              ),
            ),
          ),
          ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 680),
            child: Row(
              children: [
                for (var i = 0; i < _apps.length; i++) ...[
                  if (i > 0) const SizedBox(width: 7),
                  Expanded(
                    child: _LaunchTile(
                      label: _apps[i].label,
                      icon: _apps[i].icon,
                      onTap: () {
                        HapticFeedback.selectionClick();
                        onLaunchApp(_apps[i].target);
                      },
                    ),
                  ),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _LaunchTile extends StatelessWidget {
  final String label;
  final IconData icon;
  final VoidCallback onTap;

  const _LaunchTile({
    required this.label,
    required this.icon,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(14),
        onTap: onTap,
        child: Ink(
          height: 52,
          decoration: BoxDecoration(
            color: const Color(0xFF061326),
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: const Color(0x665EE1FF), width: 0.9),
            gradient: const LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [Color(0xFF0E1D33), Color(0xFF07101E)],
            ),
            boxShadow: const [
              BoxShadow(
                color: Color(0x1F5EE1FF),
                blurRadius: 14,
                offset: Offset(0, 3),
              ),
            ],
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, color: const Color(0xFF7FE9FF), size: 17),
              const SizedBox(width: 5),
              Flexible(
                child: Text(
                  label,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: Color(0xFFEAF6FF),
                    fontSize: 9.5,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 0.15,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

enum _HudQueryTarget { ai, google }

/// Compact typed/voice input dock: ask JARVIX, or send the same query to Google.
class JarvixCommandDock extends StatefulWidget {
  final TextEditingController controller;
  final ValueChanged<String> onAskJarvix;
  final Future<void> Function(String query) onGoogleSearch;
  final Future<void> Function() onVoiceTap;
  final bool isListening;
  final bool isBusy;

  const JarvixCommandDock({
    super.key,
    required this.controller,
    required this.onAskJarvix,
    required this.onGoogleSearch,
    required this.onVoiceTap,
    required this.isListening,
    required this.isBusy,
  });

  @override
  State<JarvixCommandDock> createState() => _JarvixCommandDockState();
}

class _JarvixCommandDockState extends State<JarvixCommandDock> {
  static const _accent = Color(0xFF5EE1FF);
  _HudQueryTarget _target = _HudQueryTarget.ai;

  Future<void> _submit() async {
    final query = widget.controller.text.trim();
    if (query.isEmpty || widget.isBusy) return;

    HapticFeedback.lightImpact();
    if (_target == _HudQueryTarget.google) {
      widget.controller.clear();
      await widget.onGoogleSearch(query);
    } else {
      widget.onAskJarvix(query);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(14, 2, 14, 2),
      child: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 680),
          child: Container(
            padding: const EdgeInsets.fromLTRB(10, 9, 8, 8),
            decoration: BoxDecoration(
              color: const Color(0xF1061428),
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: const Color(0x995EE1FF), width: 1.0),
              boxShadow: const [
                BoxShadow(
                  color: Color(0x245EE1FF),
                  blurRadius: 18,
                  spreadRadius: 1,
                  offset: Offset(0, 4),
                ),
              ],
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Row(
                  children: [
                    Expanded(
                      child: _TargetButton(
                        label: 'ASK JARVIX',
                        icon: Icons.auto_awesome_rounded,
                        selected: _target == _HudQueryTarget.ai,
                        onTap: () => setState(() => _target = _HudQueryTarget.ai),
                      ),
                    ),
                    const SizedBox(width: 7),
                    Expanded(
                      child: _TargetButton(
                        label: 'GOOGLE RESEARCH',
                        icon: Icons.search_rounded,
                        selected: _target == _HudQueryTarget.google,
                        onTap: () => setState(() => _target = _HudQueryTarget.google),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 7),
                Row(
                  children: [
                    Expanded(
                      child: TextField(
                        controller: widget.controller,
                        enabled: !widget.isBusy,
                        minLines: 1,
                        maxLines: 3,
                        textInputAction: TextInputAction.send,
                        onSubmitted: (_) => _submit(),
                        style: const TextStyle(
                          color: Color(0xFFEAF6FF),
                          fontSize: 13,
                          height: 1.25,
                        ),
                        decoration: InputDecoration(
                          isDense: true,
                          filled: true,
                          fillColor: const Color(0xFF0A1B33),
                          hintText: widget.isBusy
                              ? 'JARVIX is processing…'
                              : _target == _HudQueryTarget.google
                                  ? 'Type a topic to research…'
                                  : 'Type a question or command…',
                          hintStyle: TextStyle(
                            color: Colors.white.withValues(alpha: 0.42),
                            fontSize: 12,
                          ),
                          prefixIcon: Icon(
                            _target == _HudQueryTarget.google
                                ? Icons.travel_explore_rounded
                                : Icons.bolt_rounded,
                            color: _accent,
                            size: 19,
                          ),
                          contentPadding: const EdgeInsets.symmetric(
                            horizontal: 11,
                            vertical: 11,
                          ),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(13),
                            borderSide: BorderSide.none,
                          ),
                          enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(13),
                            borderSide: BorderSide.none,
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(13),
                            borderSide: const BorderSide(
                              color: Color(0xAA5EE1FF),
                              width: 1,
                            ),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 4),
                    IconButton(
                      tooltip: widget.isListening ? 'Stop voice input' : 'Speak a query',
                      visualDensity: VisualDensity.compact,
                      onPressed: widget.isBusy ? null : widget.onVoiceTap,
                      icon: Icon(
                        widget.isListening ? Icons.mic_rounded : Icons.mic_none_rounded,
                        color: widget.isListening ? Colors.white : _accent,
                      ),
                      style: IconButton.styleFrom(
                        backgroundColor: widget.isListening
                            ? _accent
                            : _accent.withValues(alpha: 0.12),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                          side: BorderSide(
                            color: _accent.withValues(alpha: 0.5),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 3),
                    IconButton.filled(
                      tooltip: _target == _HudQueryTarget.google
                          ? 'Search Google'
                          : 'Ask JARVIX',
                      visualDensity: VisualDensity.compact,
                      onPressed: widget.isBusy ? null : _submit,
                      icon: Icon(
                        _target == _HudQueryTarget.google
                            ? Icons.search_rounded
                            : Icons.arrow_upward_rounded,
                        size: 19,
                      ),
                      style: IconButton.styleFrom(
                        foregroundColor: Colors.white,
                        backgroundColor: _accent,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _TargetButton extends StatelessWidget {
  final String label;
  final IconData icon;
  final bool selected;
  final VoidCallback onTap;

  const _TargetButton({
    required this.label,
    required this.icon,
    required this.selected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 180),
      decoration: BoxDecoration(
        color: selected ? const Color(0x3D5EE1FF) : const Color(0xFF0A172A),
        borderRadius: BorderRadius.circular(11),
        border: Border.all(
          color: selected
              ? const Color(0xCC5EE1FF)
              : const Color(0x24FFFFFF),
          width: selected ? 1 : 0.8,
        ),
        boxShadow: selected
            ? const [
                BoxShadow(color: Color(0x245EE1FF), blurRadius: 10),
              ]
            : null,
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(11),
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 5),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(
                  icon,
                  size: 14,
                  color: selected ? const Color(0xFF7FE9FF) : Colors.white60,
                ),
                const SizedBox(width: 5),
                Flexible(
                  child: Text(
                    label,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      color: selected ? Colors.white : Colors.white70,
                      fontSize: 8.5,
                      fontWeight: FontWeight.w800,
                      letterSpacing: 0.55,
                      fontFamily: 'monospace',
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
